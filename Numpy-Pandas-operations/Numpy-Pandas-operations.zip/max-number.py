import numpy as np
import random
m = np.array([1,2,3,4,6])
  
print("\nPrinting the array:\n\n",m)

m.sort()
print("\nThe maximun number  is:")
print(np.max(m[-1]))