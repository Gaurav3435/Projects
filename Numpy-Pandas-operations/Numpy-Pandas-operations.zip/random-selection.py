import numpy as np
import random
m = [1, 2,3,4]
print("\nPrinting the list:\n\n",m)
print("\n The Random number fro the list is:\n")
print(random.choice(m))